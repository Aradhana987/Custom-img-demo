export const initialValuesForSignUp = {
    firstName: '',
    lastName: '',
    email: '',
    countryCode: '',
    phone: '',
};

export const initialValueLoginEmail = {
    email: '',
};
export const initialValueLoginPhone = {
    countryCode: '',
    phone: '',
};
export const initialValueProfile = {
    name: '',
    email: '',
    pincode: '',
    dob: '',
    gender: '',
    phone: '',
};
